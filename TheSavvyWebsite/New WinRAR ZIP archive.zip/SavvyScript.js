﻿function HomeEnter() {
    document.getElementById("homeIcon").src = "Resources/Images/NavIconHomeHover.png";
}
function HomeLeave() {
    document.getElementById("homeIcon").src = "Resources/Images/NavIconHomeDefault.png";
}
function AboutEnter() {
    document.getElementById("AboutIcon").src = "Resources/Images/NavIconAboutHover.png";
}
function AboutLeave() {
    document.getElementById("AboutIcon").src = "Resources/Images/NavIconAboutDefault.png";
}
function ContactEnter() {
    document.getElementById("ContactIcon").src = "Resources/Images/NavIconContactHover.png";
}
function ContactLeave() {
    document.getElementById("ContactIcon").src = "Resources/Images/NavIconContactDefault.png";
}
function ContentEnter() {
    document.getElementById("ContentIcon").src = "Resources/Images/NavIconContentHover.png";
}
function ContentLeave() {
    document.getElementById("ContentIcon").src = "Resources/Images/NavIconContentDefault.png";
}
function TeamEnter() {
    document.getElementById("TeamIcon").src = "Resources/Images/KhanAcademyHover.png";
}
function TeamLeave() {
    document.getElementById("TeamIcon").src = "Resources/Images/KhanAcademyDefault.png";
}